import traci
import time
from collections import defaultdict


JUNCTION_INTERNAL_PREFIX = ":J4_"


accidents = defaultdict(list)
lane_changed = defaultdict(bool)
accident_occurred = False


def check_for_accidents():
    global accident_occurred
    try:
        colliding_pairs = traci.simulation.getCollisions()
        current_time = traci.simulation.getTime()
        if colliding_pairs:
            print(f"Step {current_time}: {len(colliding_pairs)} collisioni rilevate.")
            accident_occurred = True
            for collision in colliding_pairs:
                veh1_id = collision.collider
                veh2_id = collision.victim
                lane1 = traci.vehicle.getLaneID(veh1_id) if veh1_id in traci.vehicle.getIDList() else ""
                lane2 = traci.vehicle.getLaneID(veh2_id) if veh2_id in traci.vehicle.getIDList() else ""
                if (lane1.startswith(JUNCTION_INTERNAL_PREFIX) and
                    lane2.startswith(JUNCTION_INTERNAL_PREFIX) and
                    veh1_id not in accidents and veh2_id not in accidents):
                    handle_accident(veh1_id, veh2_id, current_time)
                    print(f"Collisione tra {veh1_id} e {veh2_id} su {lane1} al tempo {current_time}")
    except traci.TraCIException as e:
        print(f"Errore nel rilevamento collisioni: {e}")


def handle_accident(veh1_id, veh2_id, collision_time):
    try:
        traci.vehicle.setSpeed(veh1_id, 0)
        traci.vehicle.setSpeed(veh2_id, 0)
        v1_class = traci.vehicle.getVehicleClass(veh1_id)
        v2_class = traci.vehicle.getVehicleClass(veh2_id)
        duration = 900 if v1_class in ["truck", "delivery", "bus"] or v2_class in ["truck", "delivery", "bus"] else 1800
        accidents[veh1_id] = [collision_time, duration]
        accidents[veh2_id] = [collision_time, duration]
        print(f"Veicoli coinvolti {veh1_id} ({v1_class}) e {veh2_id} ({v2_class}) fermati nell'incrocio per {duration/60} minuti.")
    except traci.TraCIException as e:
        print(f"Errore nella gestione incidente: {e}")


def manage_accident_duration():
    try:
        current_time = traci.simulation.getTime()
        for veh_id in list(accidents.keys()):
            start_time, duration = accidents[veh_id]
            if current_time - start_time >= duration:
                try:
                    if veh_id in traci.vehicle.getIDList():
                        traci.vehicle.remove(veh_id)
                        print(f"Veicolo coinvolto {veh_id} rimosso al tempo {current_time}")
                    del accidents[veh_id]
                except traci.TraCIException as e:
                    print(f"Errore nella rimozione: {e}")
    except traci.TraCIException as e:
        print(f"Errore nella gestione durata: {e}")


def is_lane_change_safe(veh_id, target_lane_idx):
    try:
        current_lane = traci.vehicle.getLaneIndex(veh_id)
        if current_lane == target_lane_idx:
            return True
        direction = 1 if target_lane_idx > current_lane else -1
        neighbors = traci.vehicle.getNeighbors(veh_id, direction)
        safety_distance = 10.0 if traci.vehicle.getVehicleClass(veh_id) in ["truck", "delivery", "bus"] else 3.0
        for neighbor in neighbors:
            neighbor_id, distance = neighbor
            if distance < safety_distance:
                return False
        return True
    except traci.TraCIException as e:
        print(f"Errore in is_lane_change_safe per {veh_id}: {e}")
        return False


def reroute_with_lane_change(veh_id):
    try:
        if veh_id in accidents:
            print(f"Veicolo {veh_id} coinvolto in una collisione, cambio corsia ignorato.")
            return False
       
        if lane_changed[veh_id]:
            return False
       
        v_class = traci.vehicle.getVehicleClass(veh_id)
        if v_class in ["truck", "delivery", "bus"]:
            print(f"Veicolo {veh_id} ({v_class}) non cambia corsia: cambio disabilitato per veicoli grandi.")
            return False
       
        current_lane = traci.vehicle.getLaneID(veh_id)
        current_lane_idx = traci.vehicle.getLaneIndex(veh_id)
        edge = current_lane.split('_')[0]
        lane_count = traci.edge.getLaneNumber(edge)
        print(f"Tentativo di cambio corsia per {veh_id} ({v_class}): da {current_lane_idx} su {current_lane}, corsie disponibili: {lane_count}")
       
        # Controllo: il veicolo deve essere a una distanza minima dall'incrocio
        position = traci.vehicle.getPosition(veh_id)
        junction_pos = (0, 100)  # Posizione dell'incrocio J4 (x=0, y=100)
        distance_to_junction = ((position[0] - junction_pos[0])**2 + (position[1] - junction_pos[1])**2)**0.5
        if distance_to_junction < 10:  # Distanza minima di 10 metri dall'incrocio
            print(f"Veicolo {veh_id} troppo vicino all'incrocio (distanza: {distance_to_junction:.2f} m), cambio corsia ignorato.")
            return False
       
        possible_lanes = []
        if current_lane_idx > 0:
            possible_lanes.append(current_lane_idx - 1)
        if current_lane_idx < lane_count - 1:
            possible_lanes.append(current_lane_idx + 1)
       
        for target_lane_idx in possible_lanes:
            if is_lane_change_safe(veh_id, target_lane_idx):
                duration = 2  # Proviamo con 2 invece di 1
                duration = int(max(0, min(255, duration)))
                print(f"Eseguo cambio corsia per {veh_id}: da {current_lane_idx} a {target_lane_idx} con duration={duration}")
                try:
                    traci.vehicle.changeLane(veh_id, target_lane_idx, duration)
                    lane_changed[veh_id] = True
                    print(f"Veicolo {veh_id} cambia corsia da {current_lane_idx} a {target_lane_idx} su {current_lane}")
                    return True
                except traci.TraCIException as e:
                    print(f"Errore durante il cambio corsia per {veh_id}, continuo la simulazione: {e}")
                    return False
        print(f"Veicolo {veh_id} non può cambiare corsia: nessuna corsia sicura disponibile.")
        return False
    except traci.TraCIException as e:
        print(f"Errore nel cambio corsia per {veh_id}, continuo la simulazione: {e}")
        return False
   
def main():
    global accident_occurred
    try:
        print("Tentativo di avvio di SUMO...")
        traci.start([
            "sumo-gui",
            "-c", "config.sumocfg",
            "--start",
            "--delay", "100"
        ])
        print("Simulazione avviata.")
       
        step = 0
        last_collision_step = -10  # Per gestire il ritardo dopo una collisione
        while step < 86400:
            try:
                traci.simulationStep()
               
                traci.trafficlight.setProgram("light", "0")
               
                check_for_accidents()
                manage_accident_duration()
               
                if accident_occurred:
                    if step - last_collision_step < 10:  # Aspetta 10 step dopo una collisione
                        print(f"Step {step}: Aspetto 10 step dopo l'ultima collisione prima di tentare cambi corsia.")
                    else:
                        vehicle_list = traci.vehicle.getIDList()
                        for veh_id in vehicle_list:
                            if veh_id not in accidents and not lane_changed.get(veh_id, False):
                                try:
                                    reroute_with_lane_change(veh_id)
                                except Exception as e:
                                    print(f"Errore durante il cambio corsia per {veh_id}, continuo la simulazione: {e}")
                                    continue
                    last_collision_step = step if accident_occurred else last_collision_step
               
                step += 1
            except traci.TraCIException as e:
                print(f"Errore allo step {step}: {e}")
                step += 1
                continue
       
        print("Simulazione completata.")
        traci.close()
        print("Simulazione chiusa.")
   
    except traci.TraCIException as e:
        print(f"Errore TraCI iniziale: {e}")
    except Exception as e:
        print(f"Errore inatteso: {e}")
         
main()